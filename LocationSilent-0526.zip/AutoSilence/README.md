# AutoSilence
This is an Android Application, it switches phone ringer modes(VIBRATE, SILENT, NORMAL) based on the user preferred geo-location and time.

## Before you build
Please add Google map API key to the gradle.properties file before you build the project