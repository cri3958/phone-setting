/*package com.ulan.timetable.utils;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.ulan.timetable.R;
import com.ulan.timetable.model.Week;

import java.io.File;

public class DbHelper_new extends AppCompatActivity {

    SQLiteDatabase sqliteDB2;

    private static final String DB_NAME = "timetable.db";
    private static final String TIMETABLE = "timetable";
    private static final String WEEK_ID = "id";
    private static final String WEEK_SUBJECT = "subject";
    private static final String WEEK_FRAGMENT = "fragment";
    private static final String WEEK_FROM_TIME = "fromtime";
    private static final String WEEK_MODE = "mode";
    private static final String WEEK_TO_TIME = "totime";
    private static final String WEEK_COLOR = "color";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sqliteDB2 = init_database();

        insert_values(week);

        Button buttonSave = (Button) findViewById(R.id.buttonSave);
        buttonSave.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                save_valeus();
            }
        });
        Button buttonClear = (Button) findViewById(R.id.buttonClear);
        buttonClear.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                delete_valeus();
            }
        });

    }

    private SQLiteDatabase init_database() {

        SQLiteDatabase db = null;

        File file = new File(getFilesDir(), "weektable.db");

        System.out.println("PATH : " + file.toString());

        try {
            db = SQLiteDatabase.openOrCreateDatabase(file, null)
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (db == null) {
            System.out.println("DB creation failed." + file.getAbsolutePath());

        }
        return db;
    }
    private void init_tables() {
        if (sqliteDB2 != null) {
            String sqlCreateTbl = "CREATE TABLE IF NOT EXISTS CONTACT_T (" +
                    WEEK_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    WEEK_SUBJECT + " TEXT," +
                    WEEK_FRAGMENT + " TEXT," +
                    WEEK_FROM_TIME + " TEXT," +
                    WEEK_MODE + "TEXT," +
                    WEEK_TO_TIME + " TEXT," +
                    WEEK_COLOR + " INTEGER" +  ")";

            System.out.println(sqlCreateTbl);

            sqliteDB2.execSQL(sqlCreateTbl);
        }
    }

    public void insert_values(Week week) {

        if (sqliteDB2 != null) {
            String sqlQueryTbl = "SELECT * FROM CONTACT_T";
            Cursor cursor = null;

            cursor = sqliteDB2.rawQuery(sqlQueryTbl, null);

            if (cursor.moveToNext()) {

                String subject = cursor.getString(1);
                EditText subject_dialog = (EditText) findViewById(R.id.subject_dialog);
                subject_dialog.setText(week.getSubject());


            }
        }
    }

    private void save_valeus() {
        if (sqliteDB2 != null) {
            sqliteDB2.execSQL("DELETE FROM CONTACT_T");



            System.out.println(sqlInsert);

            sqliteDB.execSQL(sqlInsert);
        }
    }

    private void delete_valeus() {
        if (sqliteDB != null) {

            String sqlDelete = "DELETE FROM CONTACT_T";


        }
    }
}*/
